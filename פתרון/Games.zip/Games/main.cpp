#include <stdio.h>
#include "BoardGameController.h"

int main()
{
    BoardGameController br;
    br.play();
    return 0;
}