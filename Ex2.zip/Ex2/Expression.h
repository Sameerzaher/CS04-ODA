#pragma once
class Expression
{
public:
    virtual double calculate() = 0;

private:
};